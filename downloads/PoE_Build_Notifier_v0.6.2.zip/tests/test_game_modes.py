"""Regression tests for v0.6.0 PoE 2 / 1.0 game-mode switching, no API credentials."""
import ast
import sqlite3
import sys
import unittest
from pathlib import Path
from datetime import datetime,timezone,timedelta
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import game_modes, storage, features, enhancements

source=(Path(__file__).resolve().parents[1]/'main.py').read_text(encoding='utf8')
root=ast.parse(source)
names={'norm','find_term','identify','classify','fingerprint','extract_links'}
funcs=[n for n in root.body if isinstance(n,ast.FunctionDef) and n.name in names]
namespace={'re':__import__('re'),'features':features,'game_modes':game_modes,'urlparse':__import__('urllib.parse',fromlist=['urlparse']).urlparse}
for n in root.body:
    if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'SKILLS','ASCENDANCIES','BUILD_SIGNALS'}:
        namespace[n.targets[0].id]=ast.literal_eval(n.value)
exec(compile(ast.Module(body=funcs,type_ignores=[]),'main_game_logic.py','exec'),namespace)


class GameModeTests(unittest.TestCase):
    def test_aliases_and_default_version(self):
        for x in ('poe2','POE 2','pathofexile2','2'):
            self.assertEqual(game_modes.normalize_game(x),'poe2')
        for x in ('poe1','PoE 1','1'):
            self.assertEqual(game_modes.normalize_game(x),'poe1')
        self.assertIsNone(game_modes.normalize_game('diablo4'))
        self.assertEqual(game_modes.DEFAULT_POE2_VERSION,'1.0')
        self.assertTrue(game_modes.valid_poe2_version('1.0'))
        self.assertFalse(game_modes.valid_poe2_version('3.30a'))

    def test_independent_versions_persist_through_reinitialize(self):
        c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row
        storage.initialize(c)
        self.assertEqual(storage.current_game(c),'poe1')
        self.assertEqual(storage.current_game_version(c,'poe2'),'1.0')
        storage.set_league(c,'3.31')
        storage.set_game(c,'poe2')
        storage.set_game_version(c,'poe2','1.1')
        self.assertEqual(storage.current_game(c),'poe2')
        self.assertEqual(storage.current_game_version(c,'poe1'),'3.31')
        self.assertEqual(storage.current_game_version(c,'poe2'),'1.1')
        storage.initialize(c)
        self.assertEqual(storage.current_game(c),'poe2')
        storage.set_game(c,'poe1')
        self.assertEqual(storage.current_game_version(c,'poe1'),'3.31')
        storage.cleanup(c,7)
        self.assertEqual(storage.current_game_version(c,'poe2'),'1.1')
        c.close()

    def test_poe2_queries_target_1_0_not_0_5(self):
        q=game_modes.target_queries('1.0')
        self.assertGreaterEqual(len(q),6)
        self.assertTrue(all('1.0' in x for x in q))
        self.assertTrue(all('PoE2' in x or 'PoE 2' in x or 'Path of Exile 2' in x for x in q))
        self.assertTrue(all('0.5' not in x and '3.30' not in x for x in q))
        self.assertEqual(game_modes.target_queries('1.1',['PoE 2 {version} best build']),['PoE 2 1.1 best build'])
        self.assertEqual(game_modes.target_queries('1.0',['PoE 2 starter']),['PoE 2 starter PoE 2 1.0'])

    def test_accept_explicit_poe2_1_0_builds(self):
        good=[
           'PoE2 1.0 BEST Starter Build Guide for New Players',
           'Path of Exile 2 1.0 Gas Grenade Mercenary Build',
           'PoE 2 1.0 League Starter – Witch',
           'Path of Exile II 1.0 Lightning Arrow Build',
           'PoE2 1.0.1 Endgame Spark Build',
        ]
        for title in good:
            with self.subTest(title=title):
                self.assertTrue(game_modes.is_target_poe2_guide(title,'',version='1.0'))
                self.assertIsNotNone(namespace['classify'](title,'',[],'1.0','poe2'))

    def test_reject_older_patches_and_unversioned_builds(self):
        invalid=[
            'PoE 2 0.5.5 best league starter build',
            'PoE2 0.3.1 Endgame Build Guide',
            'PoE2 1.1 future build guide',
            'PoE 2 1.0 from old patch 0.5.5 build',
            'PoE 2 Gas Grenade Build Guide',
            'Path of Exile 2 1.0 Patch Notes',
            'PoE 2 1.0 build tier list',
            'PoE 1 1.0 build guide',
            'PoE2 1.0 old build reupload',
        ]
        for title in invalid:
            with self.subTest(title=title):
                self.assertFalse(game_modes.is_target_poe2_guide(title,'',version='1.0'))
                self.assertIsNone(namespace['classify'](title,'',[],'1.0','poe2'))

    def test_title_patch_conflict_overrides_description(self):
        self.assertFalse(game_modes.is_target_poe2_guide('PoE2 0.5.5 Witch build','Guide for Path of Exile 2 1.0'))
        self.assertTrue(game_modes.is_target_poe2_guide('PoE 2 Gas Grenade build guide','Updated for patch 1.0 in Path of Exile 2.'))
        self.assertFalse(game_modes.is_target_poe2_guide('PoE 2 Gas Grenade build guide','A generic guide with no patch number.'))
        self.assertFalse(game_modes.is_target_poe2_guide('PoE 1 3.30 Witch build','PoE 2 1.0 coming soon'))
        self.assertFalse(game_modes.is_target_poe2_guide('PoE 2 1.0 patch reveal','New classes on December 11'))

    def test_publication_age_still_24h_in_scan(self):
        self.assertIn("'publishedAfter': (utc_now() - timedelta(hours=MAX_VIDEO_AGE_HOURS))",source)
        self.assertIn("MAX_VIDEO_AGE_HOURS) <= published <= utc_now() + timedelta(minutes=2)",source)
        self.assertIn("MAX_VIDEO_AGE_HOURS = max(1, int(os.getenv('MAX_VIDEO_AGE_HOURS', '24')))",source)

    def test_poe1_not_touched_and_poe2_recognizes_links(self):
        self.assertIsNotNone(namespace['classify']('PoE 3.30 Lightning Strike build guide','',[],'3.30','poe1'))
        self.assertIsNone(namespace['classify']('PoE 3.30 Lightning Strike build guide','',[],'1.0','poe2'))
        self.assertTrue(features.mobalytics_poe_url('https://mobalytics.gg/poe-2/builds/launch'))
        self.assertFalse(features.mobalytics_poe_url('https://mobalytics.gg/lol/builds/launch'))
        self.assertEqual(namespace['extract_links']('https://mobalytics.gg/poe-2/builds/launch')['Mobalytics'],
                         'https://mobalytics.gg/poe-2/builds/launch')

    def test_separate_saved_filters(self):
        c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row;storage.initialize(c)
        storage.set_filters(c,{'skill':'Lightning Strike'},'poe1')
        storage.set_filters(c,{'skill':'Gas Grenade'},'poe2')
        self.assertEqual(storage.get_filters(c,'poe1'),{'skill':'Lightning Strike'})
        self.assertEqual(storage.get_filters(c,'poe2'),{'skill':'Gas Grenade'})
        storage.cleanup(c,7)
        self.assertEqual(storage.get_filters(c,'poe2'),{'skill':'Gas Grenade'})
        c.close()

    def test_commands_and_query_switching_in_main(self):
        self.assertIn("@bot.command(name='Game')",source)
        self.assertIn("@bot.command(name='League')",source)
        self.assertIn("storage.set_game(c,new)",source)
        self.assertIn("storage.current_game_version(c,game",source)
        self.assertIn("game_modes.target_queries(league",source)
        self.assertIn("classify(title, description, config['exclude_phrases'], league, game)",source)
        self.assertIn("storage.get_filters(c,game)",source)
        self.assertNotIn('await message.delete(',source)


if __name__=='__main__':unittest.main()
