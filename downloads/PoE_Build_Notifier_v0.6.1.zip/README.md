# PoE Build Notifier v0.6.0 — 🇵🇱 Polski / 🇬🇧 English

[🇵🇱 Polski](#polski) · [🇬🇧 English](#english) · [Lista zmian / Patch Notes](https://bollek231.github.io/poe-build-notifier-site/changelog.html)

## Polski

**Nowość w v0.6.0: przełączanie Path of Exile 1 / Path of Exile 2 bez restartu.** PoE 2 domyślnie wyszukuje poradniki do **aktualizacji 1.0**, planowanej na 11 grudnia 2026 (PST). Zanim nadejdzie premiera, bot może wysłać nieliczne, świeże poradniki przygotowawcze do 1.0 — nie publikuje starszych filmów z 0.5 tylko dlatego, że zawierają słowo „build”.

### Najważniejsze komendy

| Komenda | Działanie |
|---|---|
| `pGame` | Wyświetla aktywną grę i wersję |
| `pGame poe2` | Przełącza na **Path of Exile 2, wersja 1.0** (domyślnie) |
| `pGame poe1` | Wraca do Path of Exile 1 i poprzednio ustawionej ligi |
| `pLeague` | Wyświetla wersję wybranej gry |
| `pLeague 1.0` | Ustawia wersję **1.0** podczas korzystania z PoE 2 |
| `pLeague 3.31` | Zmienia ligę podczas korzystania z PoE 1 |
| `pScan` | Skanuje YouTube dla **aktywnej gry** |
| `pSearch Spark` | Wyszukuje skill/build dla aktywnej gry i aktualnej wersji |

### Filtrowanie PoE 2 — bez nieaktualnych poradników

- Osobne zapytania dla PoE 2, np. `PoE2 1.0 league starter build`, `Path of Exile 2 1.0 endgame build`, `PoE 2 1.0 leveling build`.
- Wymagane rozpoznawalne oznaczenie **PoE 2**, **wersji 1.0** w tytule lub na początku opisu oraz oznaczenie buildu/poradnika w tytule.
- Odrzucane tytuły jasno wskazujące na starsze lub inne aktualizacje, np. **0.3**, **0.5**, **0.5.5**, a także zapowiedzi, reakcje i patch notes.
- Zawsze działa niezależny filtr **wieku publikacji do 24 godzin** (`publishedAfter` + lokalna weryfikacja daty). Samo „1.0” w tytule nie pozwala przesłać starego filmu.
- Osobne zapamiętywanie wersji gry oraz filtrów `pFilter` w SQLite. Historia i ustawienia PoE 1 nie znikają po przełączeniu.
- Linki z `mobalytics.gg/poe-2/...` są rozpoznawane jako przyciski **Mobalytics**.

**Uwaga:** to filtr zachowawczy. Poradnik bez wyraźnego oznaczenia 1.0 może zostać pominięty nawet jeśli jest aktualny. Po premierze można rozszerzyć słowa kluczowe w przyszłej aktualizacji.

### Instalacja / aktualizacja Windows

1. Zatrzymaj bota przez `Ctrl + C` i wykonaj kopię folderu `D:\PoE-Bot`.
2. Wypakuj `PoE_Build_Notifier_v0.6.0.zip`, skopiuj do istniejącego folderu **`main.py`, `storage.py`, `features.py`, `game_modes.py`, `enhancements.py`, `services.py`, `backups.py`, `requirements.txt`, `VERSION`**. Podmień pliki kodu.
3. **Nie nadpisuj** `.env`, `search_config.json`, `poe330_seen.sqlite3` ani folderu `backups`.
4. Otwórz CMD:

```bat
cd /d D:\PoE-Bot
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

5. Na Discordzie sprawdź `pHealth`, potem wpisz `pGame poe2`, `pLeague` i `pScan`. Jeśli nie zaakceptowałeś zasad, najpierw użyj `pPrivacy` i `pAgree`.

**Pierwsza instalacja:** utwórz `.venv` przez `py -m venv .venv`, zainstaluj zależności, skopiuj `.env.example` do `.env`, podaj własne `DISCORD_TOKEN`, `YOUTUBE_API_KEY` i `DISCORD_CHANNEL_ID`. Nigdy nie publikuj prawdziwego `.env`.

### Inne funkcje bez zmian

Skan co **2 godziny**, wiek filmów **24 h**, **3 s** między wiadomościami, przyciski PoB/Maxroll/Mobalytics, dzienne podsumowanie o **20:00 czasu polskiego**, limit 429 i lokalny licznik wyszukiwań, zaufane/zablokowane kanały, filtry, kopie bazy, alerty, `pVersion`, czyszczenie lokalnych danych YouTube po 7 dniach. **Bot nie usuwa automatycznie wiadomości z Discorda.**

### Opcjonalne ustawienia `.env`

```env
TARGET_LEAGUE=3.30
POE2_TARGET_VERSION=1.0
MAX_VIDEO_AGE_HOURS=24
CHECK_INTERVAL_HOURS=2
SEND_DELAY_SECONDS=3
YOUTUBE_CACHE_DAYS=7
```

`TARGET_LEAGUE` i `POE2_TARGET_VERSION` to ustawienia początkowe: zmiany przez `pLeague` są pamiętane w SQLite, także po restarcie. Stare `search_config.json` nadal działa bez zmian; nowa opcjonalna lista `poe2_search_queries` znajduje się w `search_config.example.json`.

**Bezpieczeństwo:** repozytorium nie zawiera tokenów, kluczy API, bazy danych ani prywatnych kopii zapasowych. Na Railway/VPS użyj trwałego woluminu, np. `DB_PATH=/data/poe330_seen.sqlite3` i `BACKUP_DIR=/data/backups`.

**Testy:** `python -m unittest discover -s tests -v`.

---

## English

**New in v0.6.0: switch between Path of Exile 1 and Path of Exile 2 without restarting.** PoE 2 searches for **version 1.0** by default, ahead of its announced December 11, 2026 PST full release. Before launch, it may find freshly published 1.0 build preparation guides; it does not publish old 0.5 videos simply because their titles contain “build”.

### Commands

| Command | What it does |
|---|---|
| `pGame` | Show the active game and target version |
| `pGame poe2` | Switch to **Path of Exile 2, version 1.0** by default |
| `pGame poe1` | Return to PoE 1 with its previous league version |
| `pLeague` | Show the active version |
| `pLeague 1.0` | Select **1.0** when PoE 2 is active |
| `pLeague 3.31` | Change the PoE 1 league when PoE 1 is active |
| `pScan` | Scan YouTube for builds for the **selected game** |
| `pSearch Spark` | Search builds for the selected game and patch |

### Strict 1.0 filtering for PoE 2

- Dedicated search phrases such as `PoE2 1.0 league starter build`, `Path of Exile 2 1.0 endgame build`, `PoE 2 1.0 leveling build`.
- Requires identifiable **PoE 2**, **patch 1.0** near the beginning of the content, and a build/guide signal in the video title.
- Rejects titles explicitly marked for older patches **0.3**, **0.5**, **0.5.5**, as well as news, reactions, tier lists, and trailers.
- Applies YouTube's `publishedAfter` plus an independent **24-hour publication-age check**; a 1.0 label alone never overrides video age.
- Stores each game's version and advanced filters independently in SQLite.
- Recognizes Mobalytics PoE 2 URLs such as `mobalytics.gg/poe-2/builds/...`.

The filter intentionally prioritizes accuracy over recall. A legitimate fresh video without an explicit 1.0 marker may be skipped.

### Upgrade (Windows)

1. Stop the bot and back up `D:\PoE-Bot`.
2. Extract `PoE_Build_Notifier_v0.6.0.zip` and replace **`main.py`, `storage.py`, `features.py`, `game_modes.py`, `enhancements.py`, `services.py`, `backups.py`, `requirements.txt`, `VERSION`**.
3. **Keep your own** `.env`, `search_config.json`, `poe330_seen.sqlite3`, and private backups.
4. Run:

```bat
cd /d D:\PoE-Bot
.venv\Scripts\activate
python -m pip install -r requirements.txt
python main.py
```

5. On Discord, use `pHealth`, `pGame poe2`, `pLeague`, then `pScan`. The bot requires `pPrivacy` and `pAgree` before administrative commands unless already accepted.

For first-time installation, create a virtual environment (`py -m venv .venv`), install dependencies, copy `.env.example` to `.env`, and supply your own Discord token, YouTube API key, and channel ID.

### Existing features retained

2-hour automatic scans, 24-hour video age window, 3-second message delay, PoB/Maxroll/Mobalytics buttons, 8 PM Warsaw-time digest, 429 quota protection, channel allow/block rules, filters, private SQLite backups, alerts, `pVersion`, and 7-day cleanup of local YouTube metadata. **Discord messages are not automatically deleted.**

### Optional `.env` settings

```env
TARGET_LEAGUE=3.30
POE2_TARGET_VERSION=1.0
MAX_VIDEO_AGE_HOURS=24
CHECK_INTERVAL_HOURS=2
SEND_DELAY_SECONDS=3
YOUTUBE_CACHE_DAYS=7
```

`pLeague` persists the per-game version to SQLite; the environment variables are initial defaults. Existing `search_config.json` files remain compatible, with an optional `poe2_search_queries` list for customization.

For Railway/VPS, use persistent storage for `DB_PATH` and `BACKUP_DIR`. Never commit secrets, the database, or backups to a public repository.

Offline tests: `python -m unittest discover -s tests -v`.

[🇵🇱 Changelog](https://bollek231.github.io/poe-build-notifier-site/changelog.html) · [🇬🇧 Patch Notes](https://bollek231.github.io/poe-build-notifier-site/changelog-en.html) · [GitHub source](https://github.com/Bollek231/poe-build-notifier-site/tree/main/bot)
